package com.example.mxclone

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.io.File

class CustomVideoAdapter(
    private var videos: List<VideoItem>,
    private val onItemClick: (VideoItem) -> Unit,
    private val onLongItemClick: (VideoItem) -> Unit
) : RecyclerView.Adapter<CustomVideoAdapter.VideoVH>() {

    private val selectedItems = mutableSetOf<VideoItem>()

    class VideoVH(view: View) : RecyclerView.ViewHolder(view) {
        val ivThumb: ImageView = view.findViewById(R.id.ivThumb)
        val ivSelectOverlay: ImageView = view.findViewById(R.id.ivSelectOverlay)
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvFolder: TextView = view.findViewById(R.id.tvFolder)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoVH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_video, parent, false)
        return VideoVH(view)
    }

    override fun onBindViewHolder(holder: VideoVH, position: Int) {
        val item = videos[position]
        holder.tvTitle.text = item.title
        holder.tvFolder.text = item.folderName

        Glide.with(holder.itemView.context)
            .load(File(item.path))
            .centerCrop()
            .error(android.R.drawable.ic_menu_slideshow)
            .into(holder.ivThumb)

        holder.ivSelectOverlay.visibility = if (selectedItems.contains(item)) View.VISIBLE else View.GONE

        holder.itemView.setOnClickListener { onItemClick(item) }
        holder.itemView.setOnLongClickListener {
            onLongItemClick(item)
            true
        }
    }

    override fun getItemCount() = videos.size

    fun updateList(newList: List<VideoItem>) {
        videos = newList
        notifyDataSetChanged()
    }

    fun setSelections(selections: Set<VideoItem>) {
        selectedItems.clear()
        selectedItems.addAll(selections)
        notifyDataSetChanged()
    }

    fun clearSelections() {
        selectedItems.clear()
        notifyDataSetChanged()
    }
}
