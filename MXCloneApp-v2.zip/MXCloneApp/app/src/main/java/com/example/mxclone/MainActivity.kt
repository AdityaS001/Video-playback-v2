package com.example.mxclone

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var normalHeader: View
    private lateinit var selectionHeader: View
    private lateinit var bottomToolbar: View
    private lateinit var tvHeaderTitle: TextView
    private lateinit var tvSelectedCount: TextView
    private lateinit var btnCancelSelection: View
    private lateinit var btnMenuOptions: View
    private lateinit var chipPrivacy: View

    private lateinit var adapter: CustomVideoAdapter
    private lateinit var vaultManager: PrivateVaultManager

    private var currentList = mutableListOf<VideoItem>()
    private var selectedVideos = mutableSetOf<VideoItem>()
    private var inSelectionMode = false
    private var showingPrivate = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        vaultManager = PrivateVaultManager(this)

        recyclerView = findViewById(R.id.recyclerView)
        normalHeader = findViewById(R.id.normalHeader)
        selectionHeader = findViewById(R.id.selectionHeader)
        bottomToolbar = findViewById(R.id.bottomToolbar)
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        tvSelectedCount = findViewById(R.id.tvSelectedCount)
        btnCancelSelection = findViewById(R.id.btnCancelSelection)
        btnMenuOptions = findViewById(R.id.btnMenuOptions)
        chipPrivacy = findViewById(R.id.chipPrivacy)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = CustomVideoAdapter(emptyList(),
            onItemClick = { video ->
                if (inSelectionMode) {
                    toggleSelection(video)
                } else {
                    val intent = Intent(this, PlayerActivity::class.java)
                    intent.putExtra("VIDEO_PATH", video.path)
                    intent.putExtra("VIDEO_TITLE", video.title)
                    startActivity(intent)
                }
            },
            onLongItemClick = { video ->
                if (!inSelectionMode) {
                    startSelectionMode(video)
                }
            }
        )
        recyclerView.adapter = adapter

        btnCancelSelection.setOnClickListener { exitSelectionMode() }
        btnMenuOptions.setOnClickListener { showContextMenu(it) }

        chipPrivacy.setOnClickListener {
            if (showingPrivate) {
                showingPrivate = false
                tvHeaderTitle.text = "Folders"
                exitSelectionMode()
                loadLocalVideos()
            } else {
                showPinDialog(isSetup = !vaultManager.isPinSet()) {
                    showingPrivate = true
                    tvHeaderTitle.text = "Private Folder"
                    exitSelectionMode()
                    loadPrivateVideos()
                }
            }
        }

        findViewById<View>(R.id.actionCheck).setOnClickListener {
            if (selectedVideos.size == currentList.size) {
                exitSelectionMode()
            } else {
                selectedVideos.clear()
                selectedVideos.addAll(currentList)
                updateSelectionUI()
            }
        }

        findViewById<View>(R.id.actionDelete).setOnClickListener {
            if (selectedVideos.isNotEmpty()) {
                selectedVideos.forEach { File(it.path).delete() }
                Toast.makeText(this, "Files deleted", Toast.LENGTH_SHORT).show()
                exitSelectionMode()
                if (showingPrivate) loadPrivateVideos() else loadLocalVideos()
            }
        }

        checkAndRequestPermissions()
    }

    override fun onResume() {
        super.onResume()
        if (!inSelectionMode) {
            if (showingPrivate) loadPrivateVideos() else loadLocalVideos()
        }
    }

    private fun startSelectionMode(firstItem: VideoItem) {
        inSelectionMode = true
        selectedVideos.clear()
        selectedVideos.add(firstItem)
        normalHeader.visibility = View.GONE
        selectionHeader.visibility = View.VISIBLE
        bottomToolbar.visibility = View.VISIBLE
        updateSelectionUI()
    }

    private fun exitSelectionMode() {
        inSelectionMode = false
        selectedVideos.clear()
        normalHeader.visibility = View.VISIBLE
        selectionHeader.visibility = View.GONE
        bottomToolbar.visibility = View.GONE
        adapter.clearSelections()
    }

    private fun toggleSelection(video: VideoItem) {
        if (selectedVideos.contains(video)) {
            selectedVideos.remove(video)
            if (selectedVideos.isEmpty()) {
                exitSelectionMode()
                return
            }
        } else {
            selectedVideos.add(video)
        }
        updateSelectionUI()
    }

    private fun updateSelectionUI() {
        tvSelectedCount.text = "${selectedVideos.size}/${currentList.size} Selected"
        adapter.setSelections(selectedVideos)
    }

    private fun showContextMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        if (showingPrivate) {
            popup.menu.add("Recover from Private Folder")
        } else {
            popup.menu.add("Play using...")
            popup.menu.add("Online subtitles")
            popup.menu.add("Share")
            popup.menu.add("Lock in Private Folder")
            popup.menu.add("File Transfer")
            popup.menu.add("Hide")
        }

        popup.setOnMenuItemClickListener { menuItem ->
            when (menuItem.title) {
                "Lock in Private Folder", "Hide" -> {
                    showLockConfirmationDialog()
                    true
                }
                "Recover from Private Folder" -> {
                    var count = 0
                    selectedVideos.forEach { video ->
                        if (vaultManager.recoverFromPrivate(video.path)) count++
                    }
                    Toast.makeText(this, "$count file(s) recovered", Toast.LENGTH_SHORT).show()
                    exitSelectionMode()
                    loadPrivateVideos()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun showLockConfirmationDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_private_lock, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        val tvDesc = dialogView.findViewById<TextView>(R.id.tvLockDesc)
        val count = selectedVideos.size
        val label = if (count == 1) "1 File" else "$count Files"
        tvDesc.text = "$label will be locked in your Private Folder and be accessible only by you."

        dialogView.findViewById<Button>(R.id.btnCancel).setOnClickListener {
            dialog.dismiss()
        }

        dialogView.findViewById<Button>(R.id.btnAdd).setOnClickListener {
            dialog.dismiss()
            if (!vaultManager.isPinSet()) {
                showPinDialog(true) { executeVaultLock() }
            } else {
                executeVaultLock()
            }
        }
        dialog.show()
    }

    private fun executeVaultLock() {
        var count = 0
        selectedVideos.forEach { video ->
            if (vaultManager.moveToPrivate(video.path)) {
                count++
            }
        }
        Toast.makeText(this, "$count file(s) locked in Private Folder", Toast.LENGTH_LONG).show()
        exitSelectionMode()
        loadLocalVideos()
    }

    private fun showPinDialog(isSetup: Boolean, onSuccess: () -> Unit) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = if (isSetup) "Set 4-digit PIN" else "Enter 4-digit PIN"
        }

        AlertDialog.Builder(this)
            .setTitle(if (isSetup) "Setup Private PIN" else "Unlock Private Folder")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val pin = input.text.toString()
                if (pin.length < 4) {
                    Toast.makeText(this, "PIN kam se kam 4 digits ka hona chahiye", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (isSetup) {
                    vaultManager.setPin(pin)
                    Toast.makeText(this, "PIN Set!", Toast.LENGTH_SHORT).show()
                    onSuccess()
                } else {
                    if (vaultManager.verifyPin(pin)) {
                        onSuccess()
                    } else {
                        Toast.makeText(this, "Wrong PIN!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } else {
                loadLocalVideos()
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    101
                )
            } else {
                loadLocalVideos()
            }
        }
    }

    private fun loadLocalVideos() {
        currentList.clear()
        val projection = arrayOf(
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection, null, null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val pathCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val folderCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

            while (cursor.moveToNext()) {
                val path = cursor.getString(pathCol)
                if (File(path).exists()) {
                    currentList.add(
                        VideoItem(
                            title = cursor.getString(nameCol) ?: "Unknown",
                            path = path,
                            duration = cursor.getLong(durCol),
                            folderName = cursor.getString(folderCol) ?: "Internal Storage"
                        )
                    )
                }
            }
        }
        adapter.updateList(currentList)
    }

    private fun loadPrivateVideos() {
        currentList.clear()
        currentList.addAll(vaultManager.getPrivateVideos())
        adapter.updateList(currentList)
    }
}
