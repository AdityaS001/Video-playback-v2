package com.example.mxclone

data class VideoItem(
    val title: String,
    val path: String,
    val duration: Long,
    val folderName: String,
    val isPrivate: Boolean = false
)
