package com.example.mxclone

import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.io.File
import kotlin.math.abs

class PlayerActivity : AppCompatActivity() {

    private lateinit var playerView: PlayerView
    private lateinit var tvGestureInfo: TextView
    private lateinit var btnSpeed: Button
    private lateinit var btnAspect: Button
    private lateinit var btnLock: Button

    private var player: ExoPlayer? = null
    private lateinit var audioManager: AudioManager
    private lateinit var gestureDetector: GestureDetector

    private var isLocked = false
    private val speeds = floatArrayOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f)
    private var speedIndex = 1
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames = arrayOf("Fit", "Crop", "Stretch")
    private var resizeIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        hideSystemUI()

        playerView = findViewById(R.id.playerView)
        tvGestureInfo = findViewById(R.id.tvGestureInfo)
        btnSpeed = findViewById(R.id.btnSpeed)
        btnAspect = findViewById(R.id.btnAspect)
        btnLock = findViewById(R.id.btnLock)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val videoPath = intent.getStringExtra("VIDEO_PATH") ?: return finish()

        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            val mediaItem = MediaItem.fromUri(Uri.fromFile(File(videoPath)))
            exo.setMediaItem(mediaItem)
            exo.prepare()
            exo.playWhenReady = true
        }

        setupButtons()
        setupGestures()
    }

    private fun setupButtons() {
        btnSpeed.setOnClickListener {
            speedIndex = (speedIndex + 1) % speeds.size
            val speed = speeds[speedIndex]
            player?.setPlaybackSpeed(speed)
            btnSpeed.text = "${speed}x"
        }

        btnAspect.setOnClickListener {
            resizeIndex = (resizeIndex + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[resizeIndex]
            btnAspect.text = resizeNames[resizeIndex]
        }

        btnLock.setOnClickListener {
            isLocked = !isLocked
            playerView.useController = !isLocked
            btnSpeed.visibility = if (isLocked) View.GONE else View.VISIBLE
            btnAspect.visibility = if (isLocked) View.GONE else View.VISIBLE
            btnLock.text = if (isLocked) "Unlock" else "Lock"
        }
    }

    private fun setupGestures() {
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (isLocked) return true
                val width = playerView.width
                if (e.x < width / 2) {
                    player?.seekTo(((player?.currentPosition ?: 0L) - 10000L).coerceAtLeast(0L))
                    showOverlay("<< 10s")
                } else {
                    player?.seekTo((player?.currentPosition ?: 0L) + 10000L)
                    showOverlay("10s >>")
                }
                return true
            }

            override fun onScroll(
                e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float
            ): Boolean {
                if (isLocked || e1 == null) return false
                val width = playerView.width

                if (abs(distanceY) > abs(distanceX)) {
                    if (e1.x < width / 2) {
                        val lp = window.attributes
                        val current = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
                        val newBright = (current + distanceY / 1000f).coerceIn(0.05f, 1.0f)
                        lp.screenBrightness = newBright
                        window.attributes = lp
                        showOverlay("Brightness: ${(newBright * 100).toInt()}%")
                    } else {
                        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                        val delta = if (distanceY > 0) 1 else -1
                        val newVol = (curVol + delta).coerceIn(0, maxVol)
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                        showOverlay("Volume: ${(newVol * 100) / maxVol}%")
                    }
                    return true
                }
                return false
            }
        })

        playerView.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            if (event.action == MotionEvent.ACTION_UP) {
                tvGestureInfo.postDelayed({ tvGestureInfo.visibility = View.GONE }, 700)
            }
            false
        }
    }

    private fun showOverlay(text: String) {
        tvGestureInfo.text = text
        tvGestureInfo.visibility = View.VISIBLE
    }

    private fun hideSystemUI() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
