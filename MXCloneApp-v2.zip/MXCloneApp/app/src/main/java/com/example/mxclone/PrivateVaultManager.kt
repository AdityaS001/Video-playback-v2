package com.example.mxclone

import android.content.Context
import android.media.MediaScannerConnection
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.io.File
import java.security.MessageDigest

class PrivateVaultManager(private val context: Context) {

    private val vaultDir = File(context.filesDir, "private_vault").apply {
        if (!exists()) mkdirs()
    }

    private val prefs by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "vault_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun isPinSet(): Boolean = prefs.contains("pin_hash")

    fun setPin(pin: String) {
        prefs.edit().putString("pin_hash", sha256(pin)).apply()
    }

    fun verifyPin(pin: String): Boolean {
        return prefs.getString("pin_hash", "") == sha256(pin)
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun moveToPrivate(sourcePath: String): Boolean {
        return try {
            val src = File(sourcePath)
            if (!src.exists()) return false
            val dest = File(vaultDir, "${System.currentTimeMillis()}_${src.name}")
            src.copyTo(dest, overwrite = true)
            prefs.edit().putString("orig_${dest.name}", sourcePath).apply()
            src.delete()
            MediaScannerConnection.scanFile(context, arrayOf(sourcePath), null, null)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun recoverFromPrivate(privatePath: String): Boolean {
        return try {
            val src = File(privatePath)
            if (!src.exists()) return false
            val originalPath = prefs.getString("orig_${src.name}", null)
                ?: "/storage/emulated/0/Movies/${src.name.substringAfter("_")}"
            val dest = File(originalPath)
            dest.parentFile?.mkdirs()
            src.copyTo(dest, overwrite = true)
            src.delete()
            prefs.edit().remove("orig_${src.name}").apply()
            MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), null, null)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun getPrivateVideos(): List<VideoItem> {
        return vaultDir.listFiles()?.map { file ->
            VideoItem(
                title = file.name.substringAfter("_"),
                path = file.absolutePath,
                duration = 0L,
                folderName = "Private Folder",
                isPrivate = true
            )
        } ?: emptyList()
    }
}
